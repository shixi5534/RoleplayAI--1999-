// Research-only fetcher: downloads text files from the dsh-pet repo via jsDelivr gcore mirror.
const fs = require("fs");
const path = require("path");
const BASE = "https://gcore.jsdelivr.net/gh/PC2005-cloud/dsh-pet@main/";
const OUT = path.join(__dirname, "src");

const listFile = path.join(__dirname, "fetch-list.txt");
if (!fs.existsSync(listFile)) {
  console.error("missing fetch-list.txt");
  process.exit(1);
}
const files = fs
  .readFileSync(listFile, "utf8")
  .split(/\r?\n/)
  .map((s) => s.trim())
  .filter((s) => s && !s.startsWith("#"));

(async () => {
  for (const f of files) {
    const outPath = path.join(OUT, f.replace(/\//g, "__"));
    try {
      const r = await fetch(BASE + f, { headers: { "User-Agent": "Mozilla/5.0" } });
      const t = await r.text();
      fs.mkdirSync(OUT, { recursive: true });
      fs.writeFileSync(outPath, t, "utf8");
      console.log(String(r.status).padEnd(4) + String(t.length).padStart(8) + "  " + f);
    } catch (e) {
      console.log("ERR  " + f + " : " + e.message);
    }
  }
})();
