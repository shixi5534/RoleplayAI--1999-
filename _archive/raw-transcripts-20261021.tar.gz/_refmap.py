from pathlib import Path
import re, json

SKIP = {".venv", "vendor", ".git", "node_modules", ".agent_tmp", "scratch_r12", "logs", ".idea", ".pytest_cache", ".agent", ".research-dshpet"}


def iter_all():
    for f in Path(".").rglob("*"):
        if not f.is_file():
            continue
        if any(p in f.parts for p in SKIP):
            continue
        if f.suffix.lower() not in (".md", ".py", ".js", ".html", ".css", ".json", ".toml", ".txt", ".bat", ".mermaid"):
            continue
        yield f


files = list(iter_all())
print("scanning", len(files), "files")

docs = [f for f in files if f.suffix.lower() == ".md" and (f.parts[0] == "docs")]
texts = {}
for f in files:
    try:
        texts[f] = f.read_text(encoding="utf-8", errors="replace")
    except Exception:
        texts[f] = ""

rows = []
for d in docs:
    rel = str(d.relative_to("docs")).replace("\\", "/")
    name = d.name
    stem = d.stem
    # references from OTHER files
    refs = []
    for f, t in texts.items():
        if f == d:
            continue
        if name in t or rel in t:
            refs.append(f)
    code_refs = [f for f in refs if f.suffix.lower() != ".md"]
    doc_refs = [f for f in refs if f.suffix.lower() == ".md"]
    rows.append({
        "path": str(d).replace("\\", "/"),
        "bytes": d.stat().st_size,
        "doc_refs": len(doc_refs),
        "code_refs": len(code_refs),
        "code_ref_files": [str(x).replace("\\", "/") for x in code_refs[:6]],
    })

rows.sort(key=lambda r: r["bytes"], reverse=True)
Path("_refmap.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
print(f"{'bytes':>8} {'docRef':>6} {'codeRef':>7}  path")
for r in rows:
    print(f"{r['bytes']:8,} {r['doc_refs']:6} {r['code_refs']:7}  {r['path']}")
