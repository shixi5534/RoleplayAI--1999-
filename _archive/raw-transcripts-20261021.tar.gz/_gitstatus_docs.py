import subprocess
from pathlib import Path

tracked = set()
out = subprocess.run(['git', 'ls-files', '-z', 'docs'], capture_output=True)
for b in out.stdout.split(b'\x00'):
    if b:
        tracked.add(b.decode('utf-8'))

actual = {str(p).replace('\\', '/') for p in Path('docs').rglob('*') if p.is_file()}

untracked = sorted(actual - tracked)
missing = sorted(tracked - actual)
print('tracked docs files:', len(tracked))
print('actual docs files :', len(actual))
print()
print('=== UNTRACKED (no git backup) ===')
tot = 0
for f in untracked:
    sz = Path(f).stat().st_size
    tot += sz
    print('{:>8}  {}'.format(sz, f))
print('untracked subtotal:', tot)
print()
print('=== tracked but missing on disk ===')
for f in missing:
    print('   ', f)
