from pathlib import Path

def head(p, n=8):
    t = Path(p).read_text(encoding='utf-8', errors='replace')
    lines = [l for l in t.splitlines()[:40] if l.strip()][:n]
    return '\n'.join(lines)


files = [
    'docs/compendium-rag/P10口径裁决_N_retrieval能力读数.md',
    'docs/compendium-rag/P10R2判定书_可见性过滤误伤.md',
    'docs/compendium-rag/P9_CBI交接_2026-10-12.md',
    'docs/compendium-rag/handover/交接_20261010_v9优化_P8收口_下一步P9.md',
    'docs/compendium-rag/architecture.md',
    'docs/roleplay-core/architecture/GRAPHRAG_ENHANCEMENT_PLAN.md',
    'docs/roleplay-core/architecture/GRAPHRAG加强计划书.md',
    'docs/compendium-rag/audit/四层审查记分卡_2026-10-10.md',
]
for f in files:
    p = Path(f)
    print('=' * 12, f, p.stat().st_size)
    print(head(f))
    print()

print('#' * 30, 'frontend/ dir')
tot = 0
for p in sorted(Path('docs/frontend').iterdir()):
    print('{:>7}  {}'.format(p.stat().st_size, p.name))
    tot += p.stat().st_size
print('frontend total', tot)
