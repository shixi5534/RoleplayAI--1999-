from pathlib import Path
import hashlib, re, itertools, sys

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("docs")
SKIP = {".venv", "vendor", ".git", "node_modules", ".agent_tmp", "scratch_r12", "logs", ".idea", ".pytest_cache"}
docs = []
for f in ROOT.rglob("*"):
    if not f.is_file():
        continue
    if f.suffix.lower() != ".md":
        continue
    if any(p in f.parts for p in SKIP):
        continue
    docs.append(f)
print("total md files (excl. vendor/.venv/.agent_tmp):", len(docs))


def norm(t):
    t = re.sub(r"```.*?```", "", t, flags=re.S)
    t = re.sub(r"[#>*`\-|:\s]", "", t)
    return t


sig = {}
for f in docs:
    try:
        t = f.read_text(encoding="utf-8", errors="replace")
    except Exception:
        continue
    sig[f] = norm(t)

print("\n=== exact-content duplicate groups ===")
byh = {}
for f in docs:
    try:
        h = hashlib.md5(f.read_bytes()).hexdigest()
    except Exception:
        continue
    byh.setdefault(h, []).append(f)
for h, fs in byh.items():
    if len(fs) > 1:
        print("   " + "  ==  ".join(str(x) for x in fs))

print("\n=== near-duplicate pairs (jaccard>0.55) ===")


def sh(t, k=6):
    t = t[:20000]
    return set(t[i:i + k] for i in range(0, max(0, len(t) - k), 3))


shs = {f: sh(s) for f, s in sig.items()}
cands = [f for f in shs if len(shs[f]) > 40]
for a, b in itertools.combinations(cands, 2):
    A, B = shs[a], shs[b]
    if not A or not B:
        continue
    j = len(A & B) / len(A | B)
    if j > 0.55:
        print("   {:.2f}  {}  <->  {}".format(j, a, b))
