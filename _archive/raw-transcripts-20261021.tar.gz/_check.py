from pathlib import Path
import re


def sh(t, k=6):
    t = re.sub(r'[#>*`\s\-|:]+', '', t)[:20000]
    return set(t[i:i + k] for i in range(0, max(0, len(t) - k), 3))


a = Path('docs/roleplay-core/architecture/GRAPHRAG加强计划书.md').read_text(encoding='utf-8', errors='replace')
b = Path('docs/roleplay-core/architecture/GRAPHRAG_ENHANCEMENT_PLAN.md').read_text(encoding='utf-8', errors='replace')
A, B = sh(a), sh(b)
print('graphrag jaccard %.2f' % (len(A & B) / len(A | B)))
print('CN head:', a.splitlines()[0][:80])
print('EN head:', b.splitlines()[0][:80])
print()

p9 = Path('docs/compendium-rag/P9_CBI报告.md')
t9 = p9.read_text(encoding='utf-8', errors='replace')
print('P9 contains 过期/expired in head:', '过期' in t9[:3000])
print('P9 size', p9.stat().st_size, 'lines', len(t9.splitlines()))
for cand in ['data/compendium_rag/reports/cbi_result_full.md', 'data/compendium_rag/reports/cbi/cbi_result_full.md']:
    q = Path(cand)
    print(cand, q.exists(), q.stat().st_size if q.exists() else '')
print()

# baseline chain
for f in sorted(Path('docs/compendium-rag/baseline').iterdir()):
    print(f.name, f.stat().st_size, f.read_text(encoding='utf-8', errors='replace').splitlines()[0][:70])
print()
for f in sorted(Path('docs/compendium-rag').glob('判分尺子*')):
    print(f.name, f.stat().st_size, f.read_text(encoding='utf-8', errors='replace').splitlines()[0][:70])
