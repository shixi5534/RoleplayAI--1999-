import json

rows = json.load(open('_refmap.json', encoding='utf-8'))
header = '{:>8} {:>4} {:>5}  {}'.format('bytes', 'docR', 'codeR', 'path')
print(header)
for r in rows:
    print('{:8} {:4} {:5}  {}'.format(r['bytes'], r['doc_refs'], r['code_refs'], r['path']))
