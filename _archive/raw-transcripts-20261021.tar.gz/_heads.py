import io
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

CAND = [
    "docs/compendium-rag/audit/P4生成层验收报告_20261009.md",
    "docs/compendium-rag/audit/P5人设锚定口径提案_20261009.md",
    "docs/compendium-rag/audit/P6图修复验收报告_20261009.md",
    "docs/compendium-rag/audit/P7全量复审报告_20261010.md",
    "docs/compendium-rag/audit/P8_P5判定书修正方案_20261010.md",
    "docs/compendium-rag/audit/P8巡检报告_20261010.md",
    "docs/compendium-rag/audit/四层审查记分卡_2026-10-08.md",
    "docs/compendium-rag/audit/四层审查记分卡_2026-10-10.md",
    "docs/compendium-rag/P9_CBI报告.md",
    "docs/compendium-rag/baseline/BASELINE_v4_20260927.md",
    "docs/compendium-rag/baseline/BASELINE_v6_20260928.md",
    "docs/compendium-rag/baseline-repairs/核验报告_20260927_分支A复验与R4差异归因.md",
    "docs/compendium-rag/baseline-repairs/核验报告Phase2_20260927_插入序根因闭合与tiebreak修复.md",
    "docs/compendium-rag/baseline-repairs/核验报告Phase5_20260927_R4重放链路修复.md",
    "docs/compendium-rag/recall/目标①_收口报告_20260928.md",
    "docs/compendium-rag/recall/目标①_池内miss干预报告_20260928.md",
    "docs/compendium-rag/判分尺子_CBI统一rubric.md",
]

for p in CAND:
    f = Path(p)
    if not f.exists():
        print("MISSING", p)
        continue
    t = f.read_text(encoding="utf-8", errors="replace")
    lines = [x.strip() for x in t.splitlines() if x.strip()]
    print("=" * 100)
    print(f"{p}   bytes={len(t.encode('utf-8')):,}  lines={len(lines)}")
    for l in lines[:9]:
        print("   ", l[:150])
    print("   [headings]", " | ".join(x[:40] for x in lines if x.startswith("#"))[:400])
